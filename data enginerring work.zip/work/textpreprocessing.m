original_text = fileread('txt2.txt');

% Use textscan to split the content into cells (one cell per review)
reviews = textscan(original_text, '%s', 'Delimiter', '\n');

% Extract the cell array from the result of textscan
reviews = reviews{1};


% This Convert to lowercase
lowercased_text = lower(reviews);
disp('Lowercased Text:');
disp(lowercased_text);


removePunctuation = erasePunctuation(lowercased_text);

% Tokenize the text using tokenizedDocument
tokenizedText = tokenizedDocument(removePunctuation);

% Define the stopwords
stopWords = {'the', 'and', 'is', 'in', 'at', 'of', 'on', 'for', 'with', 'it', 'he', 'she', 'us', 'me', 'their', "there's", 'i', 'this', 'to', 'as', 'was', 'were', 'but', 'you', 'that', 'my', 'very', 'it', 'be', 'by', 'an', 'had', 'has', 'have', 'get', 'they', 'we', 'when', 'here', 'will', 'amazingly', 'fast', 'was', 'were', 'are', 'with', 'all', 'than', 'because', 'more', 'just', 'got', 'but', 'they', 'were', 'you', 'in', 'was', 'front', 'of', 'who', 'by', 'it', 'at', 'was', 'was', 'very', 'and', 'so', 'at', 'their', 'and', 'a', 'at', 'is', 'well', 'so', 'at', 'is'};

% Remove stopwords manually
filteredTokens = tokenizedText;
for i = 1:numel(stopWords)
    filteredTokens = removeWords(filteredTokens, stopWords{i});
end


% Display results
disp('reviews:');
disp(reviews);

disp('Text without Punctuation:');
disp(removePunctuation);

disp('Tokenized Text without Stopwords:');
disp(filteredTokens);

%% Stemming and lemmatization

% Stemming tokens
stemmedTokens = normalizeWords(filteredTokens, 'Style', 'stem');

% Lemmatizing tokens
lemmatizedTokens = normalizeWords(filteredTokens, 'Style', 'lemma');

%% Bag-of-Words

BoWFiltered = bagOfWords(filteredTokens);
BoWStem = bagOfWords(stemmedTokens);
BoWLemma = bagOfWords(lemmatizedTokens);

% Visualize bag-of-words
figure
subplot(1, 3, 1);
wordcloud(BoWFiltered);
title('Bag of Words (Filtered)');

subplot(1, 3, 2);
wordcloud(BoWStem);
title('Bag of Words (Stemmed)');

subplot(1, 3, 3);
wordcloud(BoWLemma);
title('Bag of Words (Lemmatized)');

%% Bag-of-Words Vectorization

vectorizedDocsFilt = encode(BoWFiltered, filteredTokens);
vectorizedDocsStem = encode(BoWStem, stemmedTokens);
vectorizedDocsLemma = encode(BoWLemma, lemmatizedTokens);

vectorsFilt = full(vectorizedDocsFilt);
vectorsStem = full(vectorizedDocsStem);
vectorsLemma = full(vectorizedDocsLemma);

% Plot the vectors
figure;
subplot(2, 2, 1);
imagesc(vectorsFilt);
colormap jet
title('Bag-of-words vectorisation (filtered)');

subplot(2, 2, 2);
imagesc(vectorsStem);
colormap jet
title('Bag-of-words vectorisation (stems)');

subplot(2, 2, 3);
imagesc(vectorsLemma);
colormap jet
title('Bag-of-words vectorisation (lemmas)');

%% Term Frequency–Inverse Document Frequency

TfidTokens = tfidf(BoWFiltered, filteredTokens);
TfidStem = tfidf(BoWStem, stemmedTokens);
TfidLemma = tfidf(BoWLemma, lemmatizedTokens);

% Plot TF-IDF matrices
figure;
subplot(2, 2, 1);
imagesc(TfidTokens);
colormap jet
title('TF-ID vectorisation (filtered)');

subplot(2, 2, 2);
imagesc(TfidStem);
colormap jet
title('TF-ID vectorisation (stems)');

subplot(2, 2, 3);
imagesc(TfidLemma);
colormap jet
title('TF-ID vectorisation (lemmas)');