originalFolder = 'images';

% Get a list of all image files in the folder
originalImageFile = dir(fullfile(originalFolder, '*.jpg'));

% Loop through each image file
for i = 1:length(originalImageFile)
    % Read the image
    imagePath = fullfile(originalFolder, originalImageFile(i).name);
    originalImageData = imread(imagePath);
    
    % Display the images
    figure;
    imshow(originalImageData);
    title(['Image ' num2str(i)]);
end

%% 
originalFolderName = 'images';
resizedFolderName = 'resized_images';

% Create the resized folder if it doesn't exist
if ~exist(resizedFolderName, 'dir')
    mkdir(resizedFolderName);
end

imageFiles = dir(fullfile(originalFolderName, '*.jpg'));

% Loop through each image file
for i = 1:length(imageFiles)
    % Construct the full file paths
    originalImagePath = fullfile(originalFolderName, imageFiles(i).name);
    [~, imageName, imageExt] = fileparts(imageFiles(i).name);
    resizedImagePath = fullfile(resizedFolderName, [imageName '_resized' imageExt]);
    
    % Read the original image
    originalImage = imread(originalImagePath);
    
    % Resize the image to 500x500
    resizedImage = imresize(originalImage, [500, 500]);
    
    % Save the resized image in the resized folder
    imwrite(resizedImage, resizedImagePath);
end

%% 
resizedFolderName = 'resized_images';
imageFiles = dir(fullfile(resizedFolderName, '*.jpg'));  

% Loop through each image and perform cropping using imcrop
for i = 1:length(imageFiles)
    imagePath = fullfile(resizedFolderName, imageFiles(i).name);
    originalImage = imread(imagePath);

    % this Check if the image has already been cropped Crop all the images
    [~, name, ext] = fileparts(imageFiles(i).name);
    outputFileName = fullfile(resizedFolderName, [name '_cropped' ext]);

    if exist(outputFileName, 'file')
        % Skip cropping if the cropped image already exists in folder
        fprintf('Image "%s" already cropped. Skipping...\n', name);
    else
        % Display the image and allow the user to manually select a rectangular region
        figure;
        imshow(originalImage, 'InitialMagnification', 'fit');
        croppedImage = imcrop;  % you can manually selects the region if you want to crop

        % Close the figure
        close(gcf);

        % Check if the user chose not to crop (croppedImage is empty)
        if isempty(croppedImage)
            fprintf('Image "%s" not cropped.\n', name);
        else
            % Saves the cropped image back to the same folder with a new name
            imwrite(croppedImage, outputFileName);
            fprintf('Image "%s" cropped successfully.\n', name);
        end
    end
end


%%
% Specify the folder names
resizedFolderName = 'resized_images';

% Get a list of all files in the resized folder
imageFiles = dir(fullfile(resizedFolderName, '*.jpg')); 

% Filter out files containing "_cropped" in their names
imageFiles = imageFiles(~contains({imageFiles.name}, '_cropped'));

% Initialize cell arrays to store feature information
colorFeatures = cell(length(imageFiles), 1);
shapeFeatures = cell(length(imageFiles), 1);
textureFeatures = cell(length(imageFiles), 1);

% Loop through each image and extract features
for i = 1:length(imageFiles)
    % Read the original image
    imagePath = fullfile(resizedFolderName, imageFiles(i).name);
    originalImage = imread(imagePath);

    % Extract color features
    colorMoments = struct();
    for channel = 1:3
        channelValues = double(originalImage(:,:,channel));

        % Mean
        colorMoments.mean(channel) = mean(channelValues(:));

        % Standard Deviation
        colorMoments.std(channel) = std(channelValues(:));

        % Skewness
        colorMoments.skewness(channel) = skewness(channelValues(:));
    end
    colorFeatures{i} = colorMoments;

    % Extract shape features
    if license('test', 'Image_Toolbox')
        grayImage = rgb2gray(originalImage);
        stats = regionprops(grayImage > graythresh(grayImage), 'Area', 'Perimeter', 'Eccentricity');
        shapeFeatures{i} = struct('area', [stats.Area], 'perimeter', [stats.Perimeter], 'eccentricity', [stats.Eccentricity]);
    else
        shapeFeatures{i} = [];
    end

    % Extract texture features (requires Image Processing Toolbox)
    if license('test', 'Image_Toolbox')
        textureFeatures{i} = struct();
        textureFeatures{i}.contrast = [];
        textureFeatures{i}.correlation = [];

        grayImage = rgb2gray(originalImage);
        textureFeatures{i}.contrast = graycoprops(graycomatrix(grayImage), 'Contrast');
        textureFeatures{i}.correlation = graycoprops(graycomatrix(grayImage), 'Correlation');
    else
        textureFeatures{i} = [];
    end
end

% Save color features to a JSON file
jsonString = jsonencode(colorFeatures);
jsonFileName = 'color_features.json';
fid = fopen(jsonFileName, 'w');
fprintf(fid, jsonString);
fclose(fid);
fprintf('Color features saved to %s\n', jsonFileName);

% Save shape features to a JSON file
jsonString2 = jsonencode(shapeFeatures);
jsonFileName2 = 'shape_features.json';
fid = fopen(jsonFileName2, 'w');
fprintf(fid, jsonString2);
fclose(fid);
fprintf('Shape features saved to %s\n', jsonFileName2);

% Save texture features to a JSON file
jsonString3 = jsonencode(textureFeatures);
jsonFileName3 = 'texture_features.json';
fid = fopen(jsonFileName3, 'w');
fprintf(fid, jsonString3);
fclose(fid);
fprintf('Texture features saved to %s\n', jsonFileName3);
%%
resizedFolderName = 'resized_images';

% Get a list of all files in the input folder
imageFiles = dir(fullfile(resizedFolderName, '*.jpg')); 

% Initialize a structure to store all features
allFeatures = struct('image', cell(1, length(imageFiles)));

% Read links from a text file
linksFile = 'links.txt'; % Replace with your actual text file name
fid = fopen(linksFile, 'r');
imageLinks = textscan(fid, '%s', 'Delimiter', '\n');
fclose(fid);
imageLinks = imageLinks{1};

% Check if the number of links matches the number of images
if length(imageLinks) ~= length(imageFiles)
    error('Number of links does not match the number of images.');
end

% Loop through each image and extract features
for i = 1:length(imageFiles)
    % Read the original image
    imagePath = fullfile(resizedFolderName, imageFiles(i).name);
    originalImage = imread(imagePath);

    % Extract color features
    colorMoments = struct();
    for channel = 1:3
        channelValues = double(originalImage(:,:,channel));

        % Mean
        colorMoments.mean(channel) = mean(channelValues(:));

        % Standard Deviation
        colorMoments.std(channel) = std(channelValues(:));

        % Skewness
        colorMoments.skewness(channel) = skewness(channelValues(:));
    end

    % Extract shape features
    if license('test', 'Image_Toolbox')
        grayImage = rgb2gray(originalImage);
        stats = regionprops(grayImage > graythresh(grayImage), 'Area', 'Perimeter', 'Eccentricity');
        shapeFeatures = struct('area', [stats.Area], 'perimeter', [stats.Perimeter], 'eccentricity', [stats.Eccentricity]);
    else
        shapeFeatures = [];
    end

    % Extract texture features (requires Image Processing Toolbox)
    if license('test', 'Image_Toolbox')
        grayImage = rgb2gray(originalImage);
        textureFeatures = struct();
        textureFeatures.contrast = graycoprops(graycomatrix(grayImage), 'Contrast');
        textureFeatures.correlation = graycoprops(graycomatrix(grayImage), 'Correlation');
    else
        textureFeatures = [];
    end

    % Get the link for the current image
    currentLink = imageLinks{i};

    % Create a structure for the current image
    currentImage = struct('name', imageFiles(i).name, 'link', currentLink, 'color', colorMoments, 'shape', shapeFeatures, 'texture', textureFeatures);

    % Add the current image structure to the allFeatures array
    allFeatures(i).image = currentImage;
end

% Save all features to a JSON file
jsonString = jsonencode(allFeatures, "PrettyPrint", true);
jsonFileName = 'all_features_pretty.json';
fid = fopen(jsonFileName, 'w');
fprintf(fid, jsonString);
fclose(fid);
fprintf('All features saved to %s\n', jsonFileName);

