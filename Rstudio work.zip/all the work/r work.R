install.packages("ggplot2")
install.packages("tidyr")
library(ggplot2)
library(dplyr)
library(tidyr)

meanTable$Team <- factor(meanTable$Team, levels = meanTable$Team[order(meanTable$MeanAwayGoals, decreasing = TRUE)]) #do this first
ggplot(meanTable, aes(x = MeanAwayGoals, y = Team, fill = "blue")) +
  geom_bar(stat = "identity") +
  labs(title = "Team Rankings based on Away Goal Averages 22/23 season",
  x = "Average Away Goals", y = "") +
  theme_minimal() +
  theme(axis.text.y = element_text(hjust = 0.5, vjust = 0.5)) +
  scale_fill_manual(values = "blue")




meanTable$Team <- factor(meanTable$Team, levels = meanTable$Team[order(meanTable$MeanHomeGoals, decreasing = TRUE)])
ggplot(meanTable, aes(x = MeanHomeGoals, y = Team, fill = "orange")) +
  geom_bar(stat = "identity") +
  labs(title = "Team Rankings based on Home Goal Averages 22/23 season",
       x = "Average Home Goals", y = "") +
  theme_minimal() +
  theme(axis.text.y = element_text(hjust = 0.5, vjust = 0.5))



ggplot(Statstable, aes(x = TotalHomeGoals, y = TotalAwayGoals, color = Team)) +
  geom_point(aes(shape = "Home"), size = 3, alpha = 0.7, position = position_jitter(width = 0.3, height = 0.3)) +
  geom_point(aes(x = TotalAwayGoals, shape = "Away"), size = 3, alpha = 0.7, position = position_jitter(width = 0.3, height = 0.3)) +
  labs(x = "Total Home Goals", y = "Total Away Goals", color = "Team", shape = "") +
  scale_shape_manual(values = c(16, 17)) +
  theme_minimal() +
  theme(legend.position = "bottom", 
        legend.background = element_rect(fill = "lightgrey", size = 0.5),
        legend.title = element_text(colour = "grey10", size = 10, face = "bold"))


barplot(meanHomePossessionsTable$AverageHomePossession,
        names.arg = meanHomePossessionsTable$Month,
        main = "Average Home Possession by Month",
        xlab = "Month",
        ylab = "Average Home Possession",
        col = "white",  
        border = "black",
        ylim = c(0, 60)  # This Adjust the y-axis range
)

barplot(meanHomePossessionsTable$AverageAwayPossession,
        names.arg = meanHomePossessionsTable$Month,
        main = "Average Away Possession by Month",
        xlab = "Month",
        ylab = "Average Away Possession",
        col = "white",  
        border = "black",
        ylim = c(0, 60)  
)

barplot(meanHomePossessionsTable$MedianHomePossessions,
        names.arg = meanHomePossessionsTable$Month,
        main = "Median Home Possession by Month",
        xlab = "Month",
        ylab = "Median Home Possession",
        col = "white",  
        border = "black",
        ylim = c(0, 170)
)
axis(2, at = seq(0, 170, by = 10)) 


barplot(meanHomePossessionsTable$MedianAwayPossession,
        names.arg = meanHomePossessionsTable$Month,
        main = "Median Away Possession by Month",
        xlab = "Month",
        ylab = "Median Away Possession",
        col = "white",
        border = "black",
        ylim = c(0, 170)
)
axis(2, at = seq(0, 170, by = 10))  


# Put month in order first
MonthlyPossessionsSummary$Month <- factor(MonthlyPossessionsSummary$Month, levels = unique(MonthlyPossessionsSummary$Month))

MonthlyPossessionsSummary_long <- MonthlyPossessionsSummary %>%
  pivot_longer(cols = c(monthlyHomePossessions, monthlyAwayPossessions), names_to = "PossessionType", values_to = "Possessions")


ggplot(MonthlyPossessionsSummary_long, aes(x = Month, y = Possessions, fill = PossessionType)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.7) +
  labs(x = "Month", y = "Possessions", title = "Monthly Home and Away Possessions") +
  scale_fill_manual(values = c("monthlyHomePossessions" = "green", "monthlyAwayPossessions" = "blue"), name = "Possession Type") +
  theme_minimal()



ggplot(originaldata, aes(x = 1, y = GoalsHome)) +
  geom_boxplot(fill = "blue", alpha = 0.7, width = 0.75) +
  geom_boxplot(aes(x = 2, y = AwayGoals), fill = "red", alpha = 0.7, width = 0.75) +
  labs(title = "Distribution of GoalsHome and AwayGoals 22/23 season ",
       x = "Variable",
       y = "Value") +
  scale_x_continuous(breaks = c(1, 2), labels = c("GoalsHome", "AwayGoals")) +
  scale_y_continuous(breaks = seq(0, 10, by = 2)) + 
  coord_cartesian(ylim = c(0, 10)) +
  theme_minimal()
 

ggplot(originaldata, aes(x = 1, y = home_possessions)) +
  geom_boxplot(fill = "blue", alpha = 0.7, width = 0.75) +
  geom_boxplot(aes(x = 2, y = away_possessions), fill = "red", alpha = 0.7, width = 0.75) +
  labs(title = "Distribution of HomePossessions and AwayPossessions 22/23 season",
       x = "poessesion",
       y = "Value") +
  scale_x_continuous(breaks = c(1, 2), labels = c("home_possessions", "away_Possessions")) +
  scale_y_continuous(breaks = seq(10, 100, by = 10)) +
  coord_cartesian(ylim = c(10, 100)) +
  theme_minimal()



# Reorder the teams based on AverageAttendanceAtHome in descending order first
Statstable$Team <- factor(Statstable$Team, levels = Statstable$Team[order(Statstable$AverageAttendanceAtHome, decreasing = TRUE)])

ggplot(Statstable, aes(x = Team, y = AverageAttendanceAtHome)) +
  geom_bar(stat = "identity", fill = "skyblue", color = "black") +
  geom_text(aes(label = format(round(AverageAttendanceAtHome), nsmall = 0)), vjust = -0.5, size = 3) +
  labs(title = "Average Attendance at Home for Each Team 2022/2023 season",
       x = "Team", y = "Average Attendance") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  ylim(0, 80000)

install.packages("cowplot") 
library(cowplot)

plot1 <- ggplot(Statstable %>%
                  pivot_longer(cols = c(TotalHomeSaves, TotalAwaySaves), names_to = "SavesType", values_to = "TotalSaves"),
                aes(x = Team, y = TotalSaves, fill = SavesType)) +
  geom_bar(stat = "identity", position = "dodge", width = 0.7, color = "black") +
  labs(title = "Comparison of Total Home Saves and Total Away Saves season 2022/2023",
       x = "Team", y = "Total Saves") +
  scale_fill_manual(values = c("TotalHomeSaves" = "lightgreen", "TotalAwaySaves" = "skyblue"), name = "Saves Type") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))

plot2 <- ggplot(Statstable %>%
                  arrange(desc(GoalsConceded)),  # Arrange by GoalsConceded in descending order
                aes(x = reorder(Team, -GoalsConceded), y = GoalsConceded, fill = "GoalsConceded")) +
  geom_bar(stat = "identity", position = "dodge", color = "black") +
  labs(title = "Goals Conceded by each Team this season 2022/2023",
       x = "Team", y = "Goals Conceded") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1))
  


# Combine the two plots
combined_plots <- plot_grid(plot1, plot2, nrow = 2)

# Print to see the results
print(combined_plots)










long_data <- gather(Statstable, key = "GoalType", value = "Goals", TotalHomeGoals, TotalAwayGoals)

# Create a horizontal paired bar chart with gaps between teams
paired_bar_chart <- ggplot(long_data, aes(y = reorder(Team, Goals), x = Goals, fill = GoalType)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), color = "black") +  
  labs(title = "Total Home and Away Goals for Each Team 22/23 Season",
       y = "Team", x = "Total Goals") +
  scale_fill_manual(values = c("TotalHomeGoals" = "blue", "TotalAwayGoals" = "green")) +
  theme_minimal()

# Print the chart to see results
print(paired_bar_chart)




SeasonWinPercentage$Location <- factor(SeasonWinPercentage$Location, levels = SeasonWinPercentage$Location[order(SeasonWinPercentage$WinPercentage, decreasing = TRUE)])

# Convert WinPercentage to percentages by  x 100
SeasonWinPercentage$WinPercentage <- SeasonWinPercentage$WinPercentage * 100
ggplot(SeasonWinPercentage, aes(x = WinPercentage, y = Location, fill = Location)) +
  geom_bar(stat = "identity", width = 0.5) +  
  geom_text(aes(label = sprintf("%.1f%%", WinPercentage)), hjust = -0.2, vjust = 0.5) +  # Add values as labels
  labs(title = "Team Rankings based on Win Percentages 22/23 season",
       x = "Win Percentage (%)", y = "") +
  theme_minimal() +
  theme(axis.text.y = element_text(hjust = 0.5, vjust = 0.5)) +
  scale_fill_manual(values = rainbow(nrow(SeasonWinPercentage))) +
  xlim(0, 100)

